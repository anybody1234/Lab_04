package hust.soict.dsai.aims.cart.Cart;
import hust.soict.dsai.aims.media.Media;
import java.util.ArrayList;
public class Cart {
	 private ArrayList<Media> itemsOrdered = new ArrayList<Media>();
	 public void addMedia(Media item) {
	        if(itemsOrdered.contains(item)) {
	            System.out.println(item.getTitle() + " is already in the cart");
	        } else {
	            itemsOrdered.add(item);
	            System.out.println("Added " + item.getTitle() + " to cart");
	        }
	    }
	    public void removeMedia(Media item) {
	        if(itemsOrdered.contains(item)) {
	            itemsOrdered.remove(item);
	            System.out.println("Removed " + item.getTitle() + " from cart");
	        } else {
	            System.out.println(item.getTitle() + "is not in cart");
	        }
	    }
	public float totalCost() {
		float sum = 0.0f;
		for (Media dvd : itemsOrdered) {
			sum += dvd.getCost();
		}
		return sum;
	}
	public void printOrder() {
		System.out.println("Order Items: ");
		for (Media dvd : itemsOrdered) {
			System.out.println("- " + dvd.getTitle() + "---Cost: " + dvd.getCost());
		}
	}
	public void displayCart() {
		System.out.println("***********************CART***********************");
		System.out.println("Ordered Items:");
		float totalCost = 0;
		for (int i = 0; i < itemsOrdered.size(); i++) {
			Media dvd = itemsOrdered.get(i);
			System.out.println((i + 1) + ". " + dvd.toString());
			totalCost += dvd.getCost();
		}
		System.out.println("Total cost: " + totalCost + " $");
		System.out.println("***************************************************");
	}
	public void emptyCart() {
        itemsOrdered.removeAll(itemsOrdered);
    }
    public void sortByTitleCost() {
        Collections.sort(itemsOrdered, Media.COMPARE_BY_TITLE_COST);
    }
    public void sortByCostTitle() {
        Collections.sort(itemsOrdered, Media.COMPARE_BY_COST_TITLE);
    }
}