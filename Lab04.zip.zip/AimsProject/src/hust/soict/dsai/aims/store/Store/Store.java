package hust.soict.dsai.aims.store.Store;
import hust.soict.dsai.aims.media.*;
import java.util.ArrayList;	
public class Store {
	private ArrayList<Media> itemsInStore = new ArrayList<Media>();
    public void addMedia (Media dvd) {
        if (dvd != null) {
            itemsInStore.add(dvd);
            System.out.println("The disc \"" + dvd.getTitle() + "\" has been added to the store.");
        } else {
            System.out.println("Cannot add a null DVD to the store.");
        }
    }
    public void removeMedia(Media dvd) {
        if (itemsInStore.remove(dvd)) {
            System.out.println("The disc \"" + dvd.getTitle() + "\" has been removed from the store.");
        } else {
            System.out.println("The disc \"" + (dvd != null ? dvd.getTitle() : "Unknown") + "\" is not found in the store.");
        }
    }
    public Media searchMedia(String title) {
        for (Media media : itemsInStore) {
            if (media.getTitle().equals(title)) {
                return media;
            }
        }
        return null; 
    }
    public void displayStore() {
        System.out.println("***********************STORE***********************");
        if (itemsInStore.isEmpty()) {
            System.out.println("The store is empty.");
        } else {
            System.out.println("Available DVDs in store:");
            for (int i = 0; i < itemsInStore.size(); i++) {
                System.out.println((i + 1) + ". " + itemsInStore.get(i).toString());
            }
        }
        System.out.println("***************************************************");
    }
}
